import os
import random
import shutil

def split_data(input_folder, 
               img_output_train_folder,
               img_output_val_folder, 
               lab_output_train_folder, 
               lab_output_val_folder, 
               split_ratio=0.8):
    
    # 列舉所有 .jpg 檔案
    jpg_list = [file_name for file_name in os.listdir(input_folder) if file_name.endswith(('.jpg','.JPG'))]

    # 隨機排列檔案列表
    random.shuffle(jpg_list)

    # 計算訓練集和驗證集的分界索引
    split_index = int(len(jpg_list) * split_ratio)

    # 按設定比例分割jpg_list
    train_files = jpg_list[:split_index]
    val_files = jpg_list[split_index:]

    # 建立訓練集和驗證集的資料夾
    os.makedirs(img_output_train_folder, exist_ok=True)    # 建立images訓練集資料夾
    os.makedirs(img_output_val_folder, exist_ok=True)      # 建立images驗證集資料夾
    os.makedirs(lab_output_train_folder, exist_ok=True)    # 建立labels訓練集資料夾
    os.makedirs(lab_output_val_folder, exist_ok=True)      # 建立labels驗證集資料夾

    # 複製 .jpg 檔案到 訓練集
    for jpg_file in train_files:
        shutil.copy(os.path.join(input_folder, jpg_file),              #從此路徑
                    os.path.join(img_output_train_folder, jpg_file))   #複製到此路徑
        
        # 複製 .txt 檔案到 訓練集
        txt_file = jpg_file.replace('.jpg', '.txt').replace('.JPG', '.txt')
        shutil.copy(os.path.join(input_folder, txt_file),              #從此路徑
                    os.path.join(lab_output_train_folder, txt_file))   #複製到此路徑
        
    # 複製 .jpg 檔案到 驗證集
    for jpg_file in val_files:
        shutil.copy(os.path.join(input_folder, jpg_file),              #從此路徑
                    os.path.join(img_output_val_folder, jpg_file))     #複製到此路徑
        
        # 複製 .txt 檔案到 驗證集
        txt_file = jpg_file.replace('.jpg', '.txt').replace('.JPG', '.txt')
        shutil.copy(os.path.join(input_folder, txt_file),              #從此路徑
                    os.path.join(lab_output_val_folder, txt_file))     #複製到此路徑
        
    print("檔案複製完成")


# 設定路徑，這裡使用了原始字串 (r"...") 的語法，這樣字串內的反斜線\將被視為普通字符而不是轉義字符
input_folder_path = r"D:\earring\dinosaur"
img_output_train_path = r"D:\earring\dataset\dinosaur\images\train"
img_output_val_path = r"D:\earring\dataset\dinosaur\images\val"
lab_output_train_path = r"D:\earring\dataset\dinosaur\labels\train"
lab_output_val_path = r"D:\earring\dataset\dinosaur\labels\val"

split_data(input_folder_path, img_output_train_path, img_output_val_path,
                              lab_output_train_path, lab_output_val_path)
